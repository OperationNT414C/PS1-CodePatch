# Sources déduites de `GSCCC.GS` — « CD CodePatch v1.0 (c) Tayan »

Programme PS1 (PS-X EXE) lancé par le disque `GSCCC_GS.BIN` : un CD de triche de type Action Replay.
Ces fichiers sont issus d'une **rétro-ingénierie** : ce ne sont pas les sources d'origine. Les noms de fonctions,
de variables et les commentaires sont des **déductions** (les noms de fonctions du BIOS, eux, sont les noms publics).
En revanche l'**exactitude binaire est garantie** : chaque listing se réassemble, octet pour octet, en segment texte
d'origine (vérifié avec GNU as), et les images disque reconstruites sont identiques à celles livrées.

## Contenu

| Fichier | Rôle |
|---|---|
| `GSCCC_01_original.S` | Version 1 : programme d'origine, annoté |
| `GSCCC_02_corrige.S` | Version 2 : correction du plantage d'Ace Combat 2 (11 mots modifiés, marqués `<<< MODIFIE`) |
| `GSCCC_03_sets_fusion.S` | Version 3 : sauvegarde commune en 1 bloc + fusion de codes (triangle) + message dans la barre |
| `diff_01_vers_02_correction_initiale.diff` | Différences V1 → V2 |
| `diff_02_vers_03_sets_et_fusion.diff` | Différences V2 → V3 |
| `Makefile`, `tools/inject_text.py` | Reconstruction du segment texte et de l'image disque |
| `tools/*.py` | Outils utilisés pendant l'analyse (voir plus bas) |

## Reconstruire

Prérequis : `apt install binutils-mipsel-linux-gnu` et python3.

```
make                                   # produit GSCCC_01_original.bin, _02_corrige.bin, _03_sets_fusion.bin (0x4000 octets chacun)
make disc VERSION=GSCCC_03_sets_fusion BASE=GSCCC_GS.BIN OUT=nouveau.BIN
```

`inject_text.py` remplace le segment texte dans les secteurs 27 à 36 de l'image brute (MODE2/2352) et recalcule
l'EDC/ECC des secteurs modifiés. Le `.cue` reste `FILE "x.BIN" BINARY / TRACK 01 MODE2/2352 / INDEX 01 00:00:00`.

## Plan mémoire du programme

| Adresse | Contenu |
|---|---|
| `0x80100000-0x8010339b` | code (entrée `_start` = `0x80103324`) |
| `0x8010339c-0x801039a7` | données : chaînes, tables du menu, icône et titre de carte mémoire |
| `0x801039a8-0x8010fbb0` | bss, effacée au démarrage. Dont `pad_buf` `0x801039a8`, `pad_state` `0x801039ac`, `codes_disabled` `0x801039b0`, `slot_used[12]` `0x80103bc0`, `load_list` `0x80105bd0`, `file_buf` `0x80107550` (8 Ko), `name_buf` `0x80109550`, `code_table` `0x8010fab0` |
| `0x8010fbb0-0x801f0000` | tas (`InitHeap`) |
| RAM noyau `0x80008000-0x800082ff` | zone du moteur de codes : pointeurs d'origine `0x80008000`, délai `0x80008070`, table de codes `0x80008080` (16×8), moteur `0x80008100` |

L'en-tête PS-X EXE donne : chargement `0x80100000`, taille `0x4000`, entrée `0x80103324`, sp `0x801ffff0` ; `gp` (`0x8010b984`) est fixé par `_start`.

## Fonctionnement déduit

**Menu principal** (5 entrées, `menu_items` `0x801038a8`, sauts `menu_jump_table` `0x80103710`) : Game Start, Code Edit, Code Save Memory Card,
Code Load Memory Card, **Top Secret** (appelle `top_secret_stub`, une fonction vide).

**Table de codes** `code_table` : 16 entrées de 8 octets (mot « type+adresse » puis demi-mot « valeur » + 2 octets inutilisés).
Une entrée vide vaut `0xFFFFFFFF`. L'éditeur affiche et modifie **12 lignes** ; `launch_game` en copie 15 vers le moteur.

**Moteur de codes** (`engine`) : exécuté à chaque sortie d'exception, via le détournement de `B0[0x17]` (`ReturnFromException`).
Types gérés : `0x80` écriture 16 bits, `0x30` écriture 8 bits, `0xD0` / `0xE0` conditions « égal » 16/8 bits (saute le code suivant si différent).
Il **s'arrête au premier mot `0xFFFFFFFF`**. Un délai (`0x80008070`) suspend le moteur quelques appels après certains accès carte/manette.

**Contrôle des crédits** : au démarrage, `main` calcule somme (`0x828`) et XOR (`0x1c`) de la chaîne « CD CodePatch v1.0 (c) Tayan » ;
si elles diffèrent, `codes_disabled` passe à 1 et le moteur est désactivé. À ne pas oublier si vous modifiez ces textes.

**Touches** (disposition libetc de la variable `pad_state`) : `0x10` triangle, `0x20` rond, `0x40` croix, `0x100` select, `0x1000` haut, `0x4000` bas.

## Format des sauvegardes

* **V1 (original)** : un fichier par emplacement, `TAYAN-CDAR10-<0..9,A,B>`, 1 bloc chacun ; en-tête carte (`SC`, titre, icône) puis,
  à l'offset `0x100`, 12 entrées de 12 octets (mot +0, demi-mot +8). Seuls 12 codes sont écrits.
* **V3** : un seul fichier `TAYAN-CDAR10-SETS` (1 bloc). En-tête carte `0x000-0x0ff`, puis l'emplacement `k` à `0x200 + k×0x100` :
  octet `+0` = 1 si utilisé ; `+0x10…+0x8f` = image des 16 entrées de `code_table`. Les anciens fichiers par emplacement ne sont plus lus.

## Résumé des modifications

**V2 (correction)** — dans `launch_game`, les 10 `sw $v0, off($s2)` qui détournaient `InitPAD`, `CloseEvent`, `putchar`, `ChangeClearPad`,
`StartCARD`, `StopCARD`, `B0_4D`, `_card_write`, `_card_read`, `_new_card` sont remplacés par des `nop`. Seul le détournement de `ReturnFromException`
(qui lance le moteur) reste. Trouvé par bissection : l'un de ces relais faisait planter Ace Combat 2 à la vidéo d'intro.

**V3 (sauvegarde commune + fusion)** — nouvelles routines `sets_*` placées dans des zones mortes (relais désactivés, bloc de printf de debug de
`launch_game`, anciens blocs de balayage de fichiers) ; points d'appel modifiés dans `code_save_screen` et `code_load_screen` ;
rond = remplacement, **triangle = fusion** dans les lignes vides (les trous sont comblés d'abord, 12 lignes maximum, le reste est ignoré) ;
message `O:Load  Tri:Merge` à côté de « CodeLoad » ; les messages de debug des 11 détournements au lancement ne s'affichent plus.

## Outils (`tools/`)

Scripts utilisés pendant l'analyse, **fournis à titre de référence** (certains chemins sont codés en dur : `/home/claude`, `/mnt/user-data/...`) :
`mk_sources.py`, `doc_defs.py`, `gen_all.py` (génération/vérification des listings), `sim.py` (simulateur Unicorn avec BIOS et carte mémoire simulés),
`scen.py`, `scen_merge.py` (scénarios de test), `build_sets.py`, `build_merge.py` (assemblage des routines V3), `patch.py`, `patch2.py` (patchs de test et V2).

## Limites

Seule la V2 a été validée sur émulateur/Pocket par l'utilisateur ; la V3 a été validée par simulation et, d'après le retour de l'utilisateur, en usage.
Les noms et commentaires restent des interprétations ; le listing de la version 1 reste la référence la plus fiable.
