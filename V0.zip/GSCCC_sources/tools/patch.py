import struct
SRC='/mnt/user-data/uploads/GSCCC_GS.BIN'
S=2352; LBA0=27
orig=open(SRC,'rb').read()

# ---- EDC / ECC (ECMA-130, Mode 2 Form 1) ----
edc_t=[]
for i in range(256):
    e=i
    for _ in range(8): e=(e>>1)^(0xD8018001 if e&1 else 0)
    edc_t.append(e)
ecc_f=[0]*256; ecc_b=[0]*256
for i in range(256):
    j=((i<<1)^(0x11D if i&0x80 else 0))&0xFF
    ecc_f[i]=j; ecc_b[i^j]=i
def edc(buf):
    e=0
    for b in buf: e=(e>>8)^edc_t[(e^b)&0xFF]
    return e
def ecc_compute(src,major,minor,mult,inc,dest,off):
    size=major*minor
    for m in range(major):
        idx=(m>>1)*mult+(m&1); a=b=0
        for _ in range(minor):
            t=src[idx]; idx+=inc
            if idx>=size: idx-=size
            a^=t; b^=t; a=ecc_f[a]
        a=ecc_b[ecc_f[a]^b]
        dest[off+m]=a; dest[off+m+major]=a^b
def fix_sector(s):
    s=bytearray(s)
    s[2072:2076]=struct.pack('<I',edc(s[16:2072]))
    addr=bytes(s[12:16]); s[12:16]=b'\0\0\0\0'
    ecc_compute(bytes(s[12:]),86,24,2,86,s,0x81C)            # parité P
    ecc_compute(bytes(s[12:]),52,43,86,88,s,0x81C+172)       # parité Q (calculée après P)
    s[12:16]=addr
    return bytes(s)

# vérification de l'implémentation sur des secteurs intacts du disque
ok=all(fix_sector(orig[i*S:(i+1)*S])==orig[i*S:(i+1)*S] for i in range(16,37))
print("EDC/ECC recalculés == originaux sur les secteurs 16-36 :",ok)
assert ok

BASE=0x80100000
def foff(addr): return 0x800+(addr-BASE)       # offset dans GSCCC.GS
def jal(a): return 0x0C000000|((a>>2)&0x3FFFFFF)
def j(a):   return 0x08000000|((a>>2)&0x3FFFFFF)
NOP=0
STOPPAD,STOPCARD,FLUSH,PRINT,CAVE=0x80102ed4,0x801030cc,0x801028c8,0x8010288c,0x80100470

cave=[0x27BDFFE8,0xAFBF0010,jal(STOPPAD),NOP,jal(STOPCARD),NOP,jal(FLUSH),NOP,
      0x3C048010,jal(PRINT),0x24843590,0x8FBF0010,0x03E00008,0x27BD0018]
assert len(cave)*4<=76
patches_cleanup=[(CAVE+4*i,w) for i,w in enumerate(cave)]+[(0x801017e4,jal(CAVE))]
patches_nohooks=[(0x8010150c,j(0x801017e0)),(0x80101510,NOP)]

def build(name,patches):
    img=bytearray(orig)
    # contrôle : les mots remplacés ne touchent que ce qu'on attend
    touched=set()
    for addr,w in patches:
        o=foff(addr); lba=LBA0+o//2048; p=lba*S+24+o%2048
        img[p:p+4]=struct.pack('<I',w); touched.add(lba)
    for lba in touched:
        img[lba*S:(lba+1)*S]=fix_sector(bytes(img[lba*S:(lba+1)*S]))
    open(f'/mnt/user-data/outputs/{name}.BIN','wb').write(img)
    open(f'/mnt/user-data/outputs/{name}.cue','w').write(f'FILE "{name}.BIN" BINARY\n  TRACK 01 MODE2/2352\n    INDEX 01 00:00:00\n')
    return img,touched

for name,pt in [('GSCCC_GS_testA_sans_hooks',patches_nohooks),
                ('GSCCC_GS_testB_nettoyage',patches_cleanup),
                ('GSCCC_GS_testC_nettoyage_sans_hooks',patches_cleanup+patches_nohooks)]:
    img,t=build(name,pt)
    diff=[i for i in range(len(img)) if img[i]!=orig[i]]
    print(name,"secteurs modifiés:",sorted(t),"octets différents:",len(diff))
