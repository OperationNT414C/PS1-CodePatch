#!/usr/bin/env python3
"""Injecte un segment texte assemble (0x4000 octets, charge a 0x80100000) dans l'image disque GSCCC_GS.BIN
(BIN brut MODE2/2352), en recalculant EDC/ECC des secteurs modifies.
Usage : python3 inject_text.py GSCCC_GS.BIN texte.bin sortie.BIN
Le fichier GSCCC.GS occupe les secteurs 27..36 (en-tete PS-X EXE de 0x800 octets, puis le texte)."""
import sys, struct
S=2352; LBA0=27; NSEC=10; TEXT_OFF=0x800; TEXT_LEN=0x4000
edc_t=[]
for i in range(256):
    e=i
    for _ in range(8): e=(e>>1)^(0xD8018001 if e&1 else 0)
    edc_t.append(e)
ecc_f=[0]*256; ecc_b=[0]*256
for i in range(256):
    j=((i<<1)^(0x11D if i&0x80 else 0))&0xFF; ecc_f[i]=j; ecc_b[i^j]=i
def edc(buf):
    e=0
    for b in buf: e=(e>>8)^edc_t[(e^b)&0xFF]
    return e
def ecc(src,major,minor,mult,inc,dest,off):
    size=major*minor
    for m in range(major):
        idx=(m>>1)*mult+(m&1); a=b=0
        for _ in range(minor):
            t=src[idx]; idx+=inc
            if idx>=size: idx-=size
            a^=t; b^=t; a=ecc_f[a]
        a=ecc_b[ecc_f[a]^b]; dest[off+m]=a; dest[off+m+major]=a^b
def fix_sector(s):                      # MODE 2 FORM 1
    s=bytearray(s); s[2072:2076]=struct.pack('<I',edc(s[16:2072]))
    addr=bytes(s[12:16]); s[12:16]=b'\0'*4
    ecc(bytes(s[12:]),86,24,2,86,s,0x81C)
    ecc(bytes(s[12:]),52,43,86,88,s,0x81C+172)
    s[12:16]=addr; return bytes(s)
def main(base,text,out):
    img=bytearray(open(base,'rb').read()); new=open(text,'rb').read()
    if len(new)!=TEXT_LEN: sys.exit(f"le segment texte doit faire {TEXT_LEN} octets (recu {len(new)})")
    pay=bytearray(b"".join(img[(LBA0+i)*S+24:(LBA0+i)*S+24+2048] for i in range(NSEC)))
    if pay[:8]!=b'PS-X EXE': sys.exit("GSCCC.GS introuvable aux secteurs 27..36")
    pay[TEXT_OFF:TEXT_OFF+TEXT_LEN]=new
    changed=[]
    for i in range(NSEC):
        sec=bytes(pay[i*2048:(i+1)*2048])
        if bytes(img[(LBA0+i)*S+24:(LBA0+i)*S+24+2048])!=sec:
            img[(LBA0+i)*S+24:(LBA0+i)*S+24+2048]=sec
            img[(LBA0+i)*S:(LBA0+i+1)*S]=fix_sector(bytes(img[(LBA0+i)*S:(LBA0+i+1)*S])); changed.append(LBA0+i)
    open(out,'wb').write(img); print("secteurs modifies:",changed,"->",out)
if __name__=='__main__':
    if len(sys.argv)!=4: sys.exit(__doc__)
    main(*sys.argv[1:])
