import struct, sys
sys.path.insert(0,'/home/claude')
import build_sets as B
from capstone import *
md=B.md; BASE=B.BASE

SRC={}
SRC['H_MERGE_SEL']="""
  sll $t0,$a0,4
  sll $t1,$a0,2
  addu $t0,$t0,$t1
  lui $t2,0x8010
  addiu $t2,$t2,0x5bd0
  addu $t0,$t0,$t2
  lbu $t3,0x13($t0)
  lui $t4,0x8010
  addiu $t4,$t4,0x7750
  sll $t3,$t3,8
  addu $t4,$t4,$t3
  lbu $t5,0($t4)
  addiu $t6,$zero,15
  beqz $t5,mg_out
  addiu $t4,$t4,0x10
  lui $t7,0x8011
  addiu $t7,$t7,-0x550
  addiu $t8,$zero,12
  addiu $t9,$zero,-1
mg_src:
  lw $t0,0($t4)
  lw $t1,4($t4)
  addiu $t4,$t4,8
  beq $t0,$t9,mg_next
  nop
mg_find:
  blez $t8,mg_out
  nop
  lw $t2,0($t7)
  addiu $t8,$t8,-1
  addiu $t7,$t7,8
  bne $t2,$t9,mg_find
  nop
  sw $t0,-8($t7)
  sw $t1,-4($t7)
mg_next:
  addiu $t6,$t6,-1
  bnez $t6,mg_src
  nop
mg_out:
  jr $ra
  nop
"""
SRC['H_TRI']="""
  andi $t0,$v1,0x10
  .word {BEQ_T0_ORIG}
  nop
  jal {H_MERGE_SEL}
  move $a0,$s3
  j 0x801022b0
  nop
"""
SRC['H_TITLE']="""
  addiu $sp,$sp,-0x18
  sw $ra,0x14($sp)
  jal 0x80100770
  nop
  addiu $a0,$zero,0x88
  addiu $a1,$zero,0x10
  lui $a2,0x8010
  addiu $a2,$a2,{MSG_LO}
  jal 0x80100770
  nop
  lw $ra,0x14($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x18
"""
MSG=0x80100488
MSG_TEXT=b'O:Load  Tri:Merge\0'

def build(base_text):
    text=bytearray(base_text)
    rd=lambda a: struct.unpack_from('<I',text,a-BASE)[0]
    def wr(a,b):
        assert BASE<=a and a+len(b)<=BASE+0x4000 and len(b)%4==0
        text[a-BASE:a-BASE+len(b)]=b
    dis=lambda a: (lambda x:f"{x.mnemonic} {x.op_str}")(next(md.disasm(struct.pack('<I',rd(a)),a)))
    # --- gardes sur le code d'origine
    assert dis(0x801020f4)=='jal 0x80100770',dis(0x801020f4)
    assert dis(0x801021a8)=='beqz $v0, 0x801022a8',dis(0x801021a8)
    assert dis(0x80101554)=='lw $a1, 0x48($s2)',dis(0x80101554)
    assert dis(0x80101604)=='move $a0, $zero'
    # zones libres : R1 (restes) doit être vide ; MSG doit être vide
    assert all(b==0 for b in text[0x8010133c-BASE:0x80101394-BASE]),"R1 non vide"
    # 0x80100488..0x801004bc = reste du code mort (fonction jamais appelée) : on peut l'écraser
    # --- bloc d'affichage de debug (11 printf) -> libéré : saut par-dessus
    wr(0x80101554,asm_j(0x80101604)+struct.pack('<I',0))
    for a in range(0x8010155c,0x80101604,4): wr(a,struct.pack('<I',0))
    P_START=0x8010155c
    # --- données
    wr(MSG,MSG_TEXT.ljust(0x34,b'\0'))
    # --- placement
    syms=dict(BEQ_T0_ORIG=0,MSG_LO=MSG&0xffff,H_MERGE_SEL=0x80100000,H_TRI=0x80100000,H_TITLE=0x80100000)
    sizes={k:len(B.asm(v.format(**syms),0x80100000)) for k,v in SRC.items()}
    place={}
    place['H_MERGE_SEL']=P_START
    place['H_TRI']=0x8010133c
    place['H_TITLE']=place['H_TRI']+sizes['H_TRI']
    assert place['H_MERGE_SEL']+sizes['H_MERGE_SEL']<=0x80101604,(sizes['H_MERGE_SEL'])
    assert place['H_TITLE']+sizes['H_TITLE']<=0x80101394
    syms.update(place)
    syms['BEQ_T0_ORIG']=beq(8,0,place['H_TRI']+4,0x801022a8)
    code={}
    for k,v in SRC.items():
        b=B.asm(v.format(**syms),place[k]); assert len(b)==sizes[k]; wr(place[k],b); code[k]=(place[k],len(b))
    # --- points d'appel
    wr(0x801020f4,B.asm(f"jal {place['H_TITLE']}",0x801020f4))
    wr(0x801021a8,struct.pack('<I',beq(2,0,0x801021a8,place['H_TRI'])))
    assert dis(0x801021a8)==f"beqz $v0, {hex(place['H_TRI'])}",dis(0x801021a8)
    return bytes(text),code,sizes
def beq(rs,rt,pc,target):
    off=(target-(pc+4))>>2
    assert -0x8000<=off<0x8000
    return (4<<26)|(rs<<21)|(rt<<16)|(off&0xffff)
def asm_j(a): return struct.pack('<I',0x08000000|((a>>2)&0x3FFFFFF))
