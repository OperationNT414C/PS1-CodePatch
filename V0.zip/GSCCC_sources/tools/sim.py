import struct, re, fnmatch
from unicorn import *
from unicorn.mips_const import *

BASE=0x80100000
R=dict(zero=0,at=1,v0=2,v1=3,a0=4,a1=5,a2=6,a3=7,t0=8,t1=9,t2=10,s0=16,s1=17,s2=18,s3=19,s4=20,s5=21,s6=22,sp=29,gp=28,ra=31)
REG={n:getattr(__import__('unicorn.mips_const',fromlist=['x']),'UC_MIPS_REG_'+n.upper()) for n in R}

def stub_map(dis_path='/home/claude/dis.txt'):
    rows=[]
    for l in open(dis_path).read().splitlines():
        a,rest=l.split(': ',1); h,mn,*op=rest.split(' ',2); rows.append((int(a,16),mn,op[0] if op else ''))
    stub={}
    for i in range(len(rows)-2):
        a,mn,op=rows[i]
        m=re.match(r'\$t0, \$zero, (0xa0|0xb0|0xc0)$',op)
        if mn=='addiu' and m and rows[i+1][1]=='jr':
            m2=re.match(r'\$t1, \$zero, (0x[0-9a-f]+|\d+)$',rows[i+2][2])
            if m2: stub[a]=(m.group(1),int(m2.group(1),0))
    return stub

class Sim:
    def __init__(self, text, card=None, pads=(), table=None, trace=False):
        self.uc=Uc(UC_ARCH_MIPS, UC_MODE_MIPS32+UC_MODE_LITTLE_ENDIAN)
        self.uc.mem_map(0,0x200000)
        self.uc.mem_write(0x100000, text)
        self.card={} if card is None else {k:bytearray(v) for k,v in card.items()}   # nom -> données (0x2000)
        self.pads=list(pads); self.fds={}; self.nextfd=1
        self.screen=[]; self.prints=[]; self.log=[]; self.dirs={}
        self.stub=stub_map()
        self.hooks={}
        self.uc.reg_write(REG['gp'],0x8010B984); self.uc.reg_write(REG['sp'],0x801FFF00)
        if table is not None: self.set_table(table)
        self.uc.hook_add(UC_HOOK_CODE,self._hook)
        self.stopaddr=0x80100FF0
        self.trace=trace
    # --- mémoire
    def r(self,a,n): return bytes(self.uc.mem_read(a&0x1fffff,n))
    def w(self,a,b): self.uc.mem_write(a&0x1fffff,bytes(b))
    def r32(self,a): return struct.unpack('<I',self.r(a,4))[0]
    def w32(self,a,v): self.w(a,struct.pack('<I',v&0xffffffff))
    def cstr(self,a):
        out=b''
        while True:
            c=self.r(a,1)
            if c==b'\0': return out.decode('latin1')
            out+=c; a+=1
    def set_table(self,entries):   # entries: liste de (word, half)
        for i in range(16):
            w,h=(entries[i] if i<len(entries) else (0xffffffff,0))
            self.w32(0x8010FAB0+8*i,w); self.w(0x8010FAB0+8*i+4,struct.pack('<HH',h,0))
    def get_table(self):
        return [(self.r32(0x8010FAB0+8*i),struct.unpack('<H',self.r(0x8010FAB0+8*i+4,2))[0]) for i in range(16)]
    # --- HLE
    def reg(self,n): return self.uc.reg_read(REG[n])
    def setreg(self,n,v): self.uc.reg_write(REG[n],v&0xffffffff)
    def _ret(self,v):
        self.setreg('v0',v); self.uc.reg_write(UC_MIPS_REG_PC,self.reg('ra'))
    def _hook(self,uc,addr,size,_):
        if addr==self.stopaddr: uc.emu_stop(); return
        if addr in self.hooks:
            self.hooks[addr](); uc.emu_stop(); return
        if addr in self.stub:
            t,i=self.stub[addr]; self.bios(t,i); uc.emu_stop(); return
    def bios(self,t,i):
        a0,a1,a2,a3=[self.reg(x) for x in ('a0','a1','a2','a3')]
        k=(t,i); res=0
        if k==('0xa0',0x00):   # open
            name=self.cstr(a0); fl=a1
            n=name[5:] if name.startswith('bu00:') else name
            if fl&0x200:
                if n in self.card: res=0xffffffff
                else: self.card[n]=bytearray(0x2000); res=self._newfd(n)
            else:
                res=self._newfd(n) if n in self.card else 0xffffffff
            self.log.append(('open',name,hex(fl),res))
        elif k==('0xa0',0x02):  # read
            n=self.fds.get(a0); 
            data=bytes(self.card[n][:a2]) if n else b''
            self.w(a1,data); res=len(data); self.log.append(('read',n,a2))
        elif k==('0xa0',0x03):  # write
            n=self.fds.get(a0)
            if n: self.card[n][:a2]=self.r(a1,a2)
            res=a2; self.log.append(('write',n,a2))
        elif k==('0xa0',0x04): self.log.append(('close',self.fds.get(a0))); res=0
        elif k==('0xb0',0x42) or k==('0xb0',0x43):
            if k[1]==0x42:
                pat=self.cstr(a0)[5:]
                self.dirs[a1]=[n for n in sorted(self.card) if fnmatch.fnmatchcase(n,pat)]
            lst=self.dirs.get(a1 if k[1]==0x42 else a0,[])
            ent=a1 if k[1]==0x42 else a0
            if lst:
                nm=lst.pop(0); self.w(ent,nm.encode().ljust(20,b'\0')); res=ent
            else: res=0
        elif k==('0xb0',0x45):
            nm=self.cstr(a0)[5:]; self.card.pop(nm,None); self.log.append(('erase',nm)); res=1
        elif k==('0xa0',0x2a): self.w(a0,self.r(a1,a2)); res=a0     # memcpy
        elif k==('0xa0',0x2b): self.w(a0,bytes([a1&0xff])*a2); res=a0   # memset
        elif k==('0xa0',0x19):  # strcpy
            s=self.cstr(a1); self.w(a0,s.encode('latin1')+b'\0'); res=a0
        elif k==('0xa0',0x15):  # strcat
            d=self.cstr(a0); s=self.cstr(a1); self.w(a0+len(d),s.encode('latin1')+b'\0'); res=a0
        elif k in (('0xa0',0x1c),('0xa0',0x1e)):  # index/strchr
            s=self.cstr(a0); p=s.find(chr(a1&0xff)); res=0 if p<0 else a0+p
        elif k==('0xa0',0x3f): self.prints.append(self.cstr(a0)); res=0
        else: self.log.append(('bios?',t,hex(i)))
        self._ret(res)
    def _newfd(self,n):
        fd=self.nextfd; self.nextfd+=1; self.fds[fd]=n; return fd
    # --- UI hooks du loader
    def install_ui_hooks(self):
        def text():   # 0x80100770(x,y,str)
            self.screen.append((self.reg('a1'),self.reg('a0'),self.cstr(self.reg('a2')))); self._ret(0)
        def box(): self._ret(0)
        def pad():
            v=self.pads.pop(0) if self.pads else 0x40
            self.w32(0x801039AC,v); self._ret(0)
        def printf():
            self.prints.append(self.cstr(self.reg('a0'))); self._ret(0)
        self.hooks[0x80100770]=text; self.hooks[0x801004bc]=box; self.hooks[0x80100808]=pad; self.hooks[0x8010288c]=printf
    def call(self,addr,args=(),maxins=5_000_000):
        for n,v in zip(('a0','a1','a2','a3'),args): self.setreg(n,v)
        self.setreg('ra',self.stopaddr); self.setreg('sp',0x801FFF00)
        self.uc.emu_start(addr,self.stopaddr,count=maxins)
        # reprise après chaque HLE
        while self.uc.reg_read(UC_MIPS_REG_PC)!=self.stopaddr:
            pc=self.uc.reg_read(UC_MIPS_REG_PC)
            self.uc.emu_start(pc,self.stopaddr,count=maxins)
        return self.reg('v0')
