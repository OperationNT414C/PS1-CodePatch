import patch   # réutilise EDC/ECC et build()
NOP=0
stores={ 'InitPAD':0x801016b8,'CloseEvent':0x801016cc,'putchar':0x801016e0,'ChangeClearPad':0x801016f4,
 'ReturnFromException':0x80101708,'StartCARD':0x8010171c,'StopCARD':0x80101730,'B0_4D':0x80101744,
 'card_write':0x80101758,'card_read':0x8010176c,'new_card':0x801017dc}
def nop(names): return [(stores[n],NOP) for n in names]
allnames=list(stores)
variants={
 'GSCCC_GS_H0_copie_sans_aucun_hook': nop(allnames),
 'GSCCC_GS_H1_seulement_ReturnFromException': nop([n for n in allnames if n!='ReturnFromException']),
 'GSCCC_GS_H2_tout_sauf_ReturnFromException': nop(['ReturnFromException']),
}
for name,pt in variants.items():
    img,t=patch.build(name,pt)
    print(name,"secteurs:",sorted(t))
