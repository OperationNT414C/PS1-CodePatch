import struct, re, sys
from keystone import *
from capstone import *
ks=Ks(KS_ARCH_MIPS,KS_MODE_MIPS32+KS_MODE_LITTLE_ENDIAN)
md=Cs(CS_ARCH_MIPS,CS_MODE_MIPS32+CS_MODE_LITTLE_ENDIAN)
PRE=".set noreorder\n.set noat\n"
S=2352; BASE=0x80100000
def asm(src,addr): return bytes(ks.asm(PRE+src,addr)[0])

# --------- constantes BIOS / loader
MEMSET,MEMCPY,OPEN,READ,WRITE,CLOSE=0x8010279c,0x80102790,0x80102598,0x801025b0,0x801025bc,0x801025c8
FIRSTFILE,ERASE=0x80103054,0x80103078
NAME=0x80100470; SUFFIX=NAME+18      # données (code mort 0x80100470)
BUF_HI=0x8010
# --------- sources des routines  ({x} remplacés par adresses)
SRC={}
SRC['H_READ']="""
  addiu $sp,$sp,-0x60
  sw $ra,0x5c($sp)
  sw $s0,0x58($sp)
  lui $s0,0x8010
  addiu $s0,$s0,0x7550
  move $a0,$s0
  move $a1,$zero
  jal {MEMSET}
  addiu $a2,$zero,0x2000
  lui $a0,0x8010
  addiu $a0,$a0,{NAME_LO}
  jal {FIRSTFILE}
  addiu $a1,$sp,0x10
  beqz $v0,rd_out
  nop
  lui $a0,0x8010
  addiu $a0,$a0,{NAME_LO}
  jal {OPEN}
  addiu $a1,$zero,1
  bltz $v0,rd_out
  nop
  sw $v0,0x50($sp)
  move $a0,$v0
  move $a1,$s0
  jal {READ}
  addiu $a2,$zero,0x2000
  lw $a0,0x50($sp)
  jal {CLOSE}
  nop
rd_out:
  lw $ra,0x5c($sp)
  lw $s0,0x58($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x60
"""
SRC['H_SCAN_SAVE']="""
  addiu $sp,$sp,-0x20
  sw $ra,0x1c($sp)
  jal {H_READ}
  nop
  lui $t0,0x8010
  addiu $t0,$t0,0x7750
  lui $t1,0x8010
  addiu $t1,$t1,0x3bc0
  addiu $t2,$zero,12
ss_loop:
  lbu $t3,0($t0)
  addiu $t0,$t0,0x100
  sltu $t3,$zero,$t3
  sb $t3,0($t1)
  addiu $t2,$t2,-1
  bnez $t2,ss_loop
  addiu $t1,$t1,1
  lw $ra,0x1c($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x20
"""
SRC['H_STORE']="""
  addiu $sp,$sp,-0x20
  sw $ra,0x1c($sp)
  sw $s0,0x18($sp)
  sll $t0,$a0,8
  lui $s0,0x8010
  addiu $s0,$s0,0x7750
  addu $s0,$s0,$t0
  addiu $a0,$s0,0x10
  lui $a1,0x8011
  addiu $a1,$a1,-0x550
  jal {MEMCPY}
  addiu $a2,$zero,0x80
  addiu $t0,$zero,1
  sb $t0,0($s0)
  lw $ra,0x1c($sp)
  lw $s0,0x18($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x20
"""
SRC['H_SCAN_LOAD']="""
  addiu $sp,$sp,-0x30
  sw $ra,0x2c($sp)
  sw $s0,0x28($sp)
  sw $s1,0x24($sp)
  sw $s2,0x20($sp)
  sw $s3,0x1c($sp)
  jal {H_READ}
  nop
  lui $s0,0x8010
  addiu $s0,$s0,0x7750
  lui $s3,0x8010
  addiu $s3,$s3,0x5bd0
  move $s1,$zero
  move $s2,$zero
sl_loop:
  lbu $t0,0($s0)
  nop
  beqz $t0,sl_next
  nop
  move $a0,$s3
  lui $a1,0x8010
  addiu $a1,$a1,0x3678
  jal {MEMCPY}
  addiu $a2,$zero,9
  lui $t1,0x8010
  addu $t1,$t1,$s1
  lbu $t0,0x365c($t1)
  addiu $t2,$zero,0x30
  sb $t2,9($s3)
  sb $t0,10($s3)
  sb $zero,11($s3)
  sb $s1,19($s3)
  addiu $s3,$s3,0x14
  addiu $s2,$s2,1
sl_next:
  addiu $s0,$s0,0x100
  addiu $s1,$s1,1
  slti $t0,$s1,12
  bnez $t0,sl_loop
  nop
  move $v0,$s2
  lw $ra,0x2c($sp)
  lw $s0,0x28($sp)
  lw $s1,0x24($sp)
  lw $s2,0x20($sp)
  lw $s3,0x1c($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x30
"""
SRC['H_LOAD_SEL']="""
  addiu $sp,$sp,-0x20
  sw $ra,0x1c($sp)
  sll $t0,$a0,4
  sll $t1,$a0,2
  addu $t0,$t0,$t1
  lui $t2,0x8010
  addiu $t2,$t2,0x5bd0
  addu $t0,$t0,$t2
  lbu $t3,0x13($t0)
  nop
  sll $t3,$t3,8
  lui $t4,0x8010
  addiu $t4,$t4,0x7750
  addu $t4,$t4,$t3
  lbu $t5,0($t4)
  nop
  beqz $t5,ls_out
  nop
  lui $a0,0x8011
  addiu $a0,$a0,-0x550
  addiu $a1,$t4,0x10
  jal {MEMCPY}
  addiu $a2,$zero,0x80
ls_out:
  lw $ra,0x1c($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x20
"""
SRC['H_DELETE']="""
  addiu $sp,$sp,-0x60
  sw $ra,0x5c($sp)
  sw $s0,0x58($sp)
  sw $s1,0x54($sp)
  sll $t0,$a0,8
  lui $s0,0x8010
  addiu $s0,$s0,0x7750
  addu $s0,$s0,$t0
  lbu $t2,0($s0)
  nop
  beqz $t2,dl_out
  nop
  move $a0,$s0
  move $a1,$zero
  jal {MEMSET}
  addiu $a2,$zero,0x100
  lui $t0,0x8010
  addiu $t0,$t0,0x7750
  addiu $t1,$zero,12
dl_chk:
  lbu $t2,0($t0)
  nop
  bnez $t2,dl_write
  nop
  addiu $t1,$t1,-1
  bnez $t1,dl_chk
  addiu $t0,$t0,0x100
  lui $a0,0x8010
  addiu $a0,$a0,{NAME_LO}
  jal {ERASE}
  nop
  b dl_out
  nop
dl_write:
  lui $a0,0x8010
  addiu $a0,$a0,{NAME_LO}
  jal {OPEN}
  addiu $a1,$zero,2
  bltz $v0,dl_out
  nop
  move $s1,$v0
  move $a0,$s1
  lui $a1,0x8010
  addiu $a1,$a1,0x7550
  jal {WRITE}
  addiu $a2,$zero,0x2000
  jal {CLOSE}
  move $a0,$s1
dl_out:
  lw $ra,0x5c($sp)
  lw $s0,0x58($sp)
  lw $s1,0x54($sp)
  nop
  jr $ra
  addiu $sp,$sp,0x60
"""
# --------- régions libres (début, fin exclue)
REGIONS=[('R1',0x801012f0,0x80101394),('R2',0x801013fc,0x801014e4),('A',0x801019ec,0x80101a8c),
         ('B',0x80101c28,0x80101ca8),('D',0x80101f64,0x80101fb4),('E',0x8010206c,0x80102098),('F',0x801021c4,0x801022a8)]

def fmt(src,syms): return src.format(**syms)
def build(base_text):
    text=bytearray(base_text)
    orig=bytes(base_text)
    def rd(a): return struct.unpack_from('<I',text,a-BASE)[0]
    def wr(a,b):
        assert BASE<=a and a+len(b)<=BASE+0x4000 and len(b)%4==0
        text[a-BASE:a-BASE+len(b)]=b
    # contrôle des instructions d'origine aux points de patch
    expect={0x801019dc:0x3C048010,0x80101c14:0x3C058010,0x80101d30:0x0C04023F,0x80101d34:0x24050001,0x80101d84:0x0C0409E7,
            0x80101f50:0x00008021,0x80102058:0x3C048010,0x801021b0:0x3C108011}
    for a,w in expect.items():
        assert rd(a)==w,(hex(a),hex(rd(a)),hex(w))
    # données
    wr(NAME,b'bu00:TAYAN-CDAR10-SETS'.ljust(24,b'\0'))
    assert SUFFIX==NAME+18 and bytes(text[SUFFIX-BASE:SUFFIX-BASE+5])==b'SETS\0'
    # 1) mesurer les tailles
    base_syms=dict(MEMSET=MEMSET,MEMCPY=MEMCPY,OPEN=OPEN,READ=READ,WRITE=WRITE,CLOSE=CLOSE,FIRSTFILE=FIRSTFILE,ERASE=ERASE,
                   NAME_LO=NAME&0xffff,
                   H_READ=0x80100000,H_SCAN_SAVE=0x80100000,H_STORE=0x80100000,H_SCAN_LOAD=0x80100000,H_LOAD_SEL=0x80100000,H_DELETE=0x80100000)
    sizes={k:len(asm(fmt(v,base_syms),0x80100000)) for k,v in SRC.items()}
    # 2) placement (plus grand d'abord, premier emplacement qui convient)
    free={n:[a,e] for n,a,e in REGIONS}
    place={}
    for k in sorted(sizes,key=lambda k:-sizes[k]):
        cand=[(e-a,n) for n,(a,e) in free.items() if e-a>=sizes[k]]
        if not cand: raise SystemExit(f"pas de place pour {k} ({sizes[k]} o) ; libre={ {n:(v[1]-v[0])//4 for n,v in free.items()} }")
        _,n=min(cand); place[k]=free[n][0]; free[n][0]+=sizes[k]
    syms=dict(base_syms); syms.update({k:place[k] for k in place})
    # 3) vider les zones d'origine concernées puis écrire
    NOP=struct.pack('<I',0)
    for n,a,e in REGIONS: wr(a,NOP*((e-a)//4))
    code={}
    for k,v in SRC.items():
        b=asm(fmt(v,syms),place[k]); assert len(b)==sizes[k]; wr(place[k],b); code[k]=(place[k],len(b))
    # 4) points d'appel
    J=lambda a: struct.pack('<I',0x0C000000|((a>>2)&0x3FFFFFF))
    Jmp=lambda a: struct.pack('<I',0x08000000|((a>>2)&0x3FFFFFF))
    P=lambda *w: b''.join(struct.pack('<I',x) if isinstance(x,int) else x for x in w)
    MOVE_A0_S3=struct.unpack('<I',asm('move $a0,$s3',0))[0]; MOVE_S4_V0=struct.unpack('<I',asm('move $s4,$v0',0))[0]; NOPI=0
    # A : écran de sauvegarde, balayage
    for i in range(0x801019dc,0x801019ec,4): wr(i,NOP)
    wr(0x801019dc,P(J(place['H_SCAN_SAVE']),NOPI,Jmp(0x80101a8c),NOPI))
    # B : suppression
    for i in range(0x80101c14,0x80101c28,4): wr(i,NOP)
    wr(0x80101c14,P(MOVE_A0_S3,J(place['H_DELETE']),NOPI,Jmp(0x80101ca8),NOPI))
    # C : nom du fichier = conteneur
    wr(0x80101d30,P(0x3C028010,0x24420000|(SUFFIX&0xffff)))     # lui v0,0x8010 ; addiu v0,v0,lo(SUFFIX)
    # C2 : ne pas vider le tampon avant d'écrire
    wr(0x80101d84,P(NOPI))
    # D : copie des codes -> emplacement
    for i in range(0x80101f50,0x80101f64,4): wr(i,NOP)
    wr(0x80101f50,P(MOVE_A0_S3,J(place['H_STORE']),NOPI,Jmp(0x80101fb4),NOPI))
    # E/F : écran de chargement
    for i in range(0x80102058,0x8010206c,4): wr(i,NOP)
    wr(0x80102058,P(J(place['H_SCAN_LOAD']),NOPI,MOVE_S4_V0,Jmp(0x80102098),NOPI))
    for i in range(0x801021b0,0x801021c4,4): wr(i,NOP)
    wr(0x801021b0,P(MOVE_A0_S3,J(place['H_LOAD_SEL']),NOPI,Jmp(0x801022b0),NOPI))
    return bytes(text),code,sizes,free

def check_hazards(text,code):
    """vérifie délais de chargement R3000 et jeu d'instructions MIPS-I dans les routines ajoutées"""
    ok=True
    allowed={'addiu','addu','subu','and','or','xor','nor','andi','ori','xori','sll','srl','sra','slt','sltu','slti','sltiu','lui',
             'lw','lh','lhu','lb','lbu','sw','sh','sb','beq','bne','blez','bgtz','bltz','bgez','j','jal','jr','jalr','nop','move','b','beqz','bnez'}
    regs=lambda s:set(re.findall(r'\$(\w+)',s))
    for k,(a,n) in code.items():
        ins=list(md.disasm(text[a-BASE:a-BASE+n],a))
        assert len(ins)==n//4,(k,len(ins),n//4)
        for i,x in enumerate(ins):
            if x.mnemonic not in allowed: print("MNEMONIC NON MIPS-I:",k,hex(x.address),x.mnemonic,x.op_str); ok=False
            if x.mnemonic in('lw','lh','lhu','lb','lbu'):
                rt=x.op_str.split(',')[0].strip().lstrip('$')
                if i+1<len(ins):
                    nx=ins[i+1]
                    if rt in regs(nx.op_str) and rt!='zero':
                        print("RISQUE load-delay:",k,hex(x.address),x.mnemonic,x.op_str,'->',nx.mnemonic,nx.op_str); ok=False
                if i+1<len(ins) and ins[i-1].mnemonic in ('jal','jr','j','b','beqz','bnez','beq','bne','bltz'): print("load en delay slot:",k,hex(x.address)); ok=False
    return ok
