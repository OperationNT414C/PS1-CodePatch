import sys,os,struct,subprocess,shutil; sys.path.insert(0,'/home/claude')
import mk_sources as M
OUT='/home/claude/src_out'; os.makedirs(OUT,exist_ok=True)
V=[('orig','/mnt/user-data/uploads/GSCCC_GS.BIN'),('corrige','/mnt/user-data/outputs/GSCCC_GS_corrige.BIN'),('final','/mnt/user-data/outputs/GSCCC_GS_sets_fusion.BIN')]
texts={}
for n,p in V: hdr,texts[n]=M.get_text(p)
def words(t): return dict((M.BASE+4*i,w) for i,w in enumerate(struct.unpack('<%dI'%(len(t)//4),t)))
HEAD={
'orig':"""# GSCCC.GS - "CD CodePatch v1.0 (c) Tayan" - VERSION 1 : ORIGINALE
# Listing assembleur MIPS R3000 deduit par retro-ingenierie du fichier GSCCC.GS (disque GSCCC_GS.BIN).
# Ce n'est PAS le source d'origine : noms de fonctions/variables et commentaires sont des deductions.
# Chargement : 0x80100000 (PS-X EXE : entree 0x80103324, sp initial 0x801ffff0 ; gp = 0x8010b984 est positionne par _start), segment texte de 0x4000 octets.
# Se reassemble octet pour octet (voir Makefile : GNU as -march=r3000 -mips1).""",
'corrige':"""# GSCCC.GS - VERSION 2 : CORRECTION INITIALE (plantage d'Ace Combat 2)
# Meme programme que la version 1, avec une seule famille de changements (lignes marquees "<<< MODIFIE") :
#   dans launch_game, les 10 ecritures "sw $v0, off($s2)" qui detournaient les fonctions B0 InitPAD, CloseEvent,
#   putchar, ChangeClearPad, StartCARD, StopCARD, B0_4D, _card_write, _card_read, _new_card sont remplacees par nop.
#   Seul le detournement de ReturnFromException (B0[0x17], qui lance le moteur de codes) est conserve.
# Cause identifiee par bissection : l'un de ces 10 relais faisait planter le jeu a la video d'intro.""",
'final':"""# GSCCC.GS - VERSION 3 : sauvegarde commune (1 bloc) + FUSION de codes + message dans la barre
# Base : version 2. Modifications (lignes marquees "<<< MODIFIE", nouvelles routines [V3]) :
#  1. Un seul fichier carte memoire "TAYAN-CDAR10-SETS" (8 Ko = 1 bloc) contient les 12 emplacements :
#       en-tete carte 0x000-0x0ff ; emplacement k a 0x200 + k*0x100 :
#       +0 octet 'utilise' (1) ; +0x10 .. +0x8f image de code_table (16 entrees x 8 octets)
#  2. Ecran de chargement : rond = remplacer (comme avant) ; TRIANGLE = fusion dans les lignes libres
#     (12 lignes visibles max, les codes en trop sont ignores) ; message 'O:Load  Tri:Merge' a cote de 'CodeLoad'.
#  3. Le bloc de 11 printf de debug de launch_game est contourne (place reutilisee pour sets_merge_slot).
#  4. La zone morte 0x80100470 contient le nom du fichier et le message (donnees).""",
}
prev=None; names={}
for n,p in V:
    extra={}; data=[(0x8010339c,0x80104000)]
    if n=='final':
        extra=dict(M.FUNCS_FINAL); data=[(0x80100470,0x801004bc)]+data
        keep={0x80101394:'tpl_wrap_ReturnFromException'}
    # noms des relais (gabarit) : seulement version 1/2
    saved=dict(M.TEMPLATE)
    if n=='final': M.TEMPLATE.clear(); M.TEMPLATE.update(keep)
    t=texts[n]
    items,ins,funcs,targets,words_=M.build(t,n,extra,data,prev=prev)
    M.TEMPLATE.clear(); M.TEMPLATE.update(saved)
    src,dem=M.verify(items,t,HEAD[n])
    fn={'orig':'GSCCC_01_original.S','corrige':'GSCCC_02_corrige.S','final':'GSCCC_03_sets_fusion.S'}[n]
    open(f'{OUT}/{fn}','w').write(src)
    open(f'{OUT}/{fn[:-2]}.bin','wb').write(M.gnu_build(src) if False else open('/tmp/gnu/x.bin','rb').read())
    print(fn,"OK reassemblage exact | lignes:",src.count("\n"),"| instr en .word:",len(dem),"| modifiees vs precedente:",src.count('<<< MODIFIE'))
    prev=words(t)
