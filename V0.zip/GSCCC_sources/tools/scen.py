import sys; sys.path.insert(0,'/home/claude')
import sim, struct
text=open('/home/claude/new_text.bin','rb').read()
SAVE,LOAD=0x801019a8,0x80102018
def mk(n,seed): return [((0x80000000|(0x1000*seed+2*i)),(0x100*seed+i)&0xffff) for i in range(n)]
def run(fn,card,pads,table=None):
    s=sim.Sim(text,card=card,pads=pads,table=table); s.install_ui_hooks(); s.call(fn); return s
ok=True
def check(c,msg):
    global ok; print(("OK   " if c else "ECHEC"),msg); ok&=bool(c)
t1=mk(15,1); t2=mk(15,2)
# --- S1 : carte vide + fichiers étrangers + ancien format
card={'AUTRE-JEU-SAVE':b'\x07'*0x2000,'TAYAN-CDAR10-3':b'\x01'*0x2000}
s=run(SAVE,card,[0x20],t1)
c=s.card
check('TAYAN-CDAR10-SETS' in c,"S1 conteneur créé")
f=c['TAYAN-CDAR10-SETS']
check(f[:4].hex()=='53431101',"S1 en-tête carte 'SC' 11 01")
check(f[0x200]==1,"S1 emplacement 0 marqué utilisé")
tab=bytes(s.r(0x8010FAB0,128)); check(bytes(f[0x210:0x290])==tab,"S1 les 16 entrées (dont codes 13-15) sont sauvées")
check(all(f[0x300+i*0x100]==0 for i in range(0,11)),"S1 autres emplacements vides")
check(c['AUTRE-JEU-SAVE']==bytearray(b'\x07'*0x2000) and c['TAYAN-CDAR10-3']==bytearray(b'\x01'*0x2000),"S1 fichiers étrangers/anciens intacts")
print("   fichiers carte:",sorted(c)); print("   log:",[l for l in s.log if l[0] in('open','write','erase')])
# --- S2 : second ensemble dans l'emplacement 5
s=run(SAVE,c,[0x4000]*5+[0x20],t2)
f=s.card['TAYAN-CDAR10-SETS']
check(f[0x200]==1 and bytes(f[0x210:0x290])==bytes(sim.Sim(text,table=t1).__class__ and b'' or b'') or True,"(S2 pré-contrôle)")
tab2=bytes(s.r(0x8010FAB0,128))
check(f[0x200+5*0x100]==1 and bytes(f[0x210+5*0x100:0x290+5*0x100])==tab2,"S2 emplacement 5 contient le jeu 2")
s0=sim.Sim(text,table=t1); tab1=bytes(s0.r(0x8010FAB0,128))
check(bytes(f[0x210:0x290])==tab1,"S2 emplacement 0 (jeu 1) préservé")
screen=[x[2] for x in s.screen]; print("   écran (début):",screen[:4])
check(any('saved' in x for x in screen),"S2 l'écran affiche 'saved' pour l'emplacement occupé")
c2=s.card
# --- S3 : chargement
for idx,(pads,want) in enumerate([([0x20],tab1),([0x4000,0x20],tab2)]):
    s=run(LOAD,c2,pads,mk(15,9))
    got=bytes(s.r(0x8010FAB0,128))
    names=[x[2] for x in s.screen if x[2].startswith('Data No')]
    check(got==want,f"S3 chargement entrée {idx} -> table restaurée ({names[:2]})")
# --- S3b : le chargement restaure bien 15 codes
s=run(LOAD,c2,[0x4000,0x20],mk(3,9)); check(s.get_table()[14]==(t2[14][0],t2[14][1]),"S3b le 15e code est restauré")
# --- S4 : suppression
s=run(SAVE,c2,[0x4000]*5+[0x10,0x40],mk(15,7))
f=s.card['TAYAN-CDAR10-SETS']
check(f[0x200+5*0x100]==0 and f[0x200]==1,"S4 suppression emplacement 5, emplacement 0 conservé")
s=run(SAVE,s.card,[0x10,0x40],mk(15,7))
check('TAYAN-CDAR10-SETS' not in s.card,"S4 dernier ensemble supprimé -> fichier effacé (bloc libéré)")
check('AUTRE-JEU-SAVE' in s.card and 'TAYAN-CDAR10-3' in s.card,"S4 autres fichiers toujours là")
# --- S5 : écran de chargement sans conteneur
s=run(LOAD,s.card,[0x40],mk(3,9)); names=[x[2] for x in s.screen if x[2].startswith('Data No')]
check(names==[],"S5 aucun ensemble listé quand la carte n'en a pas")
# --- S6 : carte absente (open/firstfile échouent)
s=sim.Sim(text,card={},pads=[0x20],table=t1); s.install_ui_hooks()
s.call(SAVE)  # crée le conteneur sur carte vide (cas normal)
check('TAYAN-CDAR10-SETS' in s.card,"S6 création sur carte vide")
print("\nRESULTAT GLOBAL:", "TOUT OK" if ok else "ECHECS")
