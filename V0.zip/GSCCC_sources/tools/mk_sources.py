import struct, re, sys, collections, unicodedata
from doc_defs import DOC
fold=lambda t: unicodedata.normalize("NFKD",t).encode("ascii","ignore").decode("ascii")
sys.path.insert(0,'/home/claude')
from capstone import *
from keystone import *
import sim
md=Cs(CS_ARCH_MIPS,CS_MODE_MIPS32+CS_MODE_LITTLE_ENDIAN)
ks=Ks(KS_ARCH_MIPS,KS_MODE_MIPS32+KS_MODE_LITTLE_ENDIAN)
S=2352; BASE=0x80100000; END=BASE+0x4000; GP=0x8010B984
REGN=['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']

def get_text(path):
    d=open(path,'rb').read()
    exe=b"".join(d[(27+i)*S+24:(27+i)*S+24+2048] for i in range(10))[:18436]
    return exe[:0x800],exe[0x800:0x800+0x4000]

# ---------- noms BIOS (table A0/B0/C0, d'après la liste publique des fonctions du noyau PS1)
A0={0:'open',1:'lseek',2:'read',3:'write',4:'close',5:'ioctl',6:'exit',0x13:'setjmp',0x14:'longjmp',0x15:'strcat',0x16:'strncat',0x17:'strcmp',0x18:'strncmp',
 0x19:'strcpy',0x1a:'strncpy',0x1b:'strlen',0x1c:'index',0x1d:'rindex',0x1e:'strchr',0x1f:'strrchr',0x2a:'memcpy',0x2b:'memset',0x2c:'memmove',0x2d:'memcmp',
 0x33:'malloc',0x34:'free',0x39:'InitHeap',0x3c:'putchar',0x3e:'puts',0x3f:'printf',0x44:'FlushCache',0x45:'init_a0_b0_c0_vectors',0x46:'GPU_dw',0x47:'gpu_send_dma',
 0x48:'SendGP1Command',0x49:'GPU_cw',0x4a:'GPU_cwp',0x4b:'send_gpu_linked_list',0x51:'LoadExec',0x55:'_bu_init',0x71:'_96_init',0x72:'_96_remove'}
B0={0:'alloc_kernel_memory',7:'DeliverEvent',8:'OpenEvent',9:'CloseEvent',0xa:'WaitEvent',0xb:'TestEvent',0xc:'EnableEvent',0xd:'DisableEvent',0x12:'InitPAD',0x13:'StartPAD',
 0x14:'StopPAD',0x15:'PAD_init',0x16:'PAD_dr',0x17:'ReturnFromException',0x18:'SetDefaultExitFromException',0x19:'SetCustomExitFromException',0x3d:'std_out_putchar',
 0x41:'format',0x42:'firstfile',0x43:'nextfile',0x44:'rename',0x45:'erase',0x4a:'InitCARD',0x4b:'StartCARD',0x4c:'StopCARD',0x4d:'_card_info_subfunc',0x4e:'_card_write',
 0x4f:'_card_read',0x50:'_new_card',0x56:'GetC0Table',0x57:'GetB0Table',0x5b:'ChangeClearPad'}
C0={0:'EnqueueTimerAndVblankIrqs',1:'EnqueueSyscallHandler',2:'SysEnqIntRP',3:'SysDeqIntRP',7:'InstallExceptionHandlers',8:'SysInitMemory',0xa:'ChangeClearRCnt',0x1c:'AdjustA0Table'}
TBL={'0xa0':A0,'0xb0':B0,'0xc0':C0}

# ---------- fonctions du programme (déduites de l'analyse)
FUNCS={0x80100000:'init_system',0x80100470:'unused_gpu_helper',0x801004bc:'draw_box',0x80100508:'gpu_setup',0x80100770:'draw_text',0x80100808:'update_pad',
 0x801008fc:'hex_string',0x80100954:'top_secret_stub',0x8010095c:'code_edit',0x8010103c:'parse_system_cnf',0x80101200:'engine',0x801014f4:'launch_game',
 0x8010181c:'game_start',0x801019a8:'code_save_screen',0x80102018:'code_load_screen',0x801022d8:'main',0x80103324:'_start'}
FUNCS_FINAL={0x801019ec:'sets_read_container',0x80101f64:'sets_scan_save',0x801012f0:'sets_store_slot',0x801013fc:'sets_scan_load',0x80101c28:'sets_load_slot',
 0x801021c4:'sets_delete_slot',0x8010155c:'sets_merge_slot',0x8010133c:'sets_tri_handler',0x80101358:'sets_draw_title'}
TEMPLATE={0x801012f0:'tpl_wrap_InitPAD',0x80101318:'tpl_wrap_CloseEvent',0x80101340:'tpl_wrap_putchar',0x8010136c:'tpl_wrap_ChangeClearPad',0x80101394:'tpl_wrap_ReturnFromException',
 0x801013fc:'tpl_wrap_StartCARD',0x80101424:'tpl_wrap_StopCARD'}
STRS=[0x801033ac,0x801033c8,0x801033d4,0x801033e0,0x801033f8,0x80103408,0x80103420,0x8010343c,0x80103448,0x80103460,0x80103478,0x80103484,0x80103490,0x8010349c,
 0x801034ac,0x801034bc,0x801034d0,0x801034e4,0x801034f8,0x80103510,0x8010352c,0x8010353c,0x8010354c,0x80103558,0x8010356c,0x80103580,0x80103590,0x8010359c,0x801035bc,
 0x801035e0,0x801035f0,0x80103604,0x8010361c,0x8010363c,0x80103650,0x8010365c,0x8010366c,0x80103678,0x80103684,0x80103698,0x801036ac,0x801036d4,0x801036e4,0x801036f0,
 0x80103704,0x801038bc,0x801038d0,0x80103988,0x80103990,0x80103998,0x801039a0]
VARS={0x801039a8:'pad_buf',0x801039ac:'pad_state',0x801039b0:'codes_disabled',0x80103984:'title_ptr',0x801039c0:'hex_buf',0x80103bc0:'slot_used[12]',
      0x80105bd0:'load_list[16*0x14]',0x80107550:'file_buf[0x2000]',0x8010fab0:'code_table[16*8]',0x80103a80:'name_table',0x80109550:'name_buf'}
ARRAYS=[(0x80008000,0x8000802c,'hook_orig'),(0x80008080,0x80008100,'engine_codes'),(0x8010fab0,0x8010fb30,'code_table'),(0x80103bc0,0x80103bcc,'slot_used'),
        (0x80105bd0,0x80105d10,'load_list'),(0x80107550,0x80109550,'file_buf'),(0x80109550,0x80109700,'name_buf'),(0x801039a8,0x801039b4,'pad_vars')]
VARS.update({0x80008070:'engine_delay',0x80008074:'saved_v0',0x80008078:'saved_ra',0x80008100:'engine@kernel_ram'})
def describe(v):
    if v in VARS: return VARS[v]
    for lo,hi,nm in ARRAYS:
        if lo<=v<hi: return f"{nm}+0x{v-lo:x}"
    return None
TABLES={0x80103710:('menu_jump_table',5),0x801038a8:('menu_items',5)}

def esc(t):
    o=''
    for ch in t:
        c=ord(ch)
        if ch=='\\': o+='\\\\'
        elif ch=='"': o+='\\"'
        elif ch=='\n': o+='\\n'
        elif ch=='\t': o+='\\t'
        elif ch=='\r': o+='\\r'
        elif 32<=c<127: o+=ch
        else: o+='\\%03o'%c
    return o
def sx(v): return v-0x10000 if v&0x8000 else v

def build(text, version, extra_funcs, data_ranges, prev=None, title=''):
    funcs=dict(FUNCS); funcs.update(extra_funcs)
    # stubs BIOS
    stub=sim.stub_map()
    for a,(t,i) in stub.items(): funcs[a]=f"bios_{t[2:].upper()}_{i:02x}_{TBL[t].get(i,'?')}".replace('_?','')
    funcs.update({k:v for k,v in TEMPLATE.items() if k not in extra_funcs or version!='final'})
    data_set=[]
    for lo,hi in data_ranges: data_set.append((lo,hi))
    isdata=lambda a: any(lo<=a<hi for lo,hi in data_set)
    words=struct.unpack('<%dI'%(len(text)//4),text)
    ins={}
    for x in md.disasm(text[:len(text)],BASE):
        pass
    # désassemblage instruction par instruction (capstone s'arrête sur les mots invalides)
    for i,w in enumerate(words):
        a=BASE+4*i
        if isdata(a): continue
        g=list(md.disasm(struct.pack('<I',w),a))
        ins[a]=(w,g[0] if g else None)
    # cibles
    targets=set()
    for a,(w,x) in ins.items():
        if x and x.mnemonic in('j','jal','b','beq','bne','beqz','bnez','blez','bgtz','bltz','bgez','bltzal','bgezal'):
            m=re.search(r'0x([0-9a-f]{8})$',x.op_str)
            if m:
                t=int(m.group(1),16)
                if BASE<=t<END: targets.add(t)
    for a in funcs: targets.add(a)
    jalt={int(re.search(r'0x([0-9a-f]{8})$',x.op_str).group(1),16) for a,(w,x) in ins.items() if x and x.mnemonic=='jal' and re.search(r'0x([0-9a-f]{8})$',x.op_str)}
    name=lambda a: funcs.get(a,(f"func_{a:08x}" if a in jalt else f"L_{a:08x}"))
    # chaînes et tables
    strs={a for a in STRS if any(lo<=a<hi for lo,hi in data_set)}
    addr2str={}
    for a in STRS:
        o=a-BASE; e=text.index(b'\0',o); addr2str[a]=esc(text[o:e].decode('latin1'))
    def comment_addr(v):
        if v in addr2str: return f'"{addr2str[v]}"'
        d=describe(v)
        if d: return d
        if v in funcs: return funcs[v]
        if v in dict((k,t[0]) for k,t in TABLES.items()): return TABLES[v][0]
        return None
    lines=[]; mism=[]
    L=lines.append
    out_items=[]   # (addr, kind, text)
    # ---- code
    recent_lui={}
    for a in sorted(ins):
        w,x=ins[a]
        if a in DOC and a in funcs: out_items.append((a,'banner','\n# '+DOC[a]))
        if a in targets: out_items.append((a,'label',name(a)+':'))
        if x is None:
            out_items.append((a,'word',f"    .word 0x{w:08x}")); continue
        mn,op=x.mnemonic,x.op_str
        note=''
        # opérandes symboliques
        if mn in('j','jal','b','beq','bne','beqz','bnez','blez','bgtz','bltz','bgez','bltzal','bgezal'):
            m=re.search(r'0x([0-9a-f]{8})$',op)
            if m:
                t=int(m.group(1),16)
                op=op[:m.start()]+name(t) if t in targets else op
        elif mn=='move':
            rd=REGN[(w>>11)&31]; rs=REGN[(w>>21)&31]; rt=REGN[(w>>16)&31]
            mn='addu' if (w&0x3f)==0x21 else 'or'
            op=f"${rd}, ${rs if rt=='zero' else rt}, $zero" if rt=='zero' or rs=='zero' else op
            if (w>>21)&31==0: op=f"${rd}, $zero, ${rt}"
        # annotation lui/addiu/ori -> adresse
        mm=re.match(r'\$(\w+), 0x([0-9a-f]+)$',op) if mn=='lui' else None
        if mm: recent_lui[mm.group(1)]=(a,int(mm.group(2),16))
        if mn in('addiu','ori'):
            m2=re.match(r'\$(\w+), \$(\w+), (-?0x[0-9a-f]+)$',op)
            if m2 and m2.group(1)==m2.group(2) and m2.group(1) in recent_lui and a-recent_lui[m2.group(1)][0]<=24:
                hi=recent_lui[m2.group(1)][1]; imm=int(m2.group(3),16)
                v=((hi<<16)+(imm if mn=='ori' else imm))&0xffffffff
                c=comment_addr(v); recent_lui.pop(m2.group(1),None)
                if c: note=f"  # -> {c}"
                elif 0x80100000<=v<0x80110000: note=f"  # -> 0x{v:08x}"
        m4=re.match(r'\$\w+, (-?0x[0-9a-f]+|-?\d+)\(\$(\w+)\)$',op) if mn in('lw','sw','lb','lbu','lh','lhu','sb','sh') else None
        if m4 and m4.group(2) in recent_lui and m4.group(2)!='gp' and a-recent_lui[m4.group(2)][0]<=24:
            v=((recent_lui[m4.group(2)][1]<<16)+int(m4.group(1),0))&0xffffffff
            c=describe(v)
            note=f"  # -> 0x{v:08x}"+(f" {c}" if c else '')
        m3=re.search(r'(-?0x[0-9a-f]+)\(\$gp\)',op)
        if m3:
            v=(GP+int(m3.group(1),16))&0xffffffff; c=describe(v) or comment_addr(v)
            note=f"  # gp -> 0x{v:08x}"+(f" {c}" if c else "")
        elif re.search(r'-0x550\(',op): note="  # code_table[i].word  (0x8010fab0 + 8*i)"
        elif re.search(r'-0x54c\(',op): note="  # code_table[i].half  (0x8010fab0 + 8*i + 4)"
        mark='  # <<< MODIFIE' if (prev is not None and prev.get(a)!=w) else ''
        out_items.append((a,'ins',f"    {mn} {op}".rstrip(), w, note.strip().lstrip('# ').strip(), mark.strip().lstrip('# ').strip()))
    # ---- données
    def emit_data(lo,hi):
        a=lo
        while a<hi:
            if a in targets or a in VARS or a in TABLES: pass
            if a in TABLES:
                nm,n=TABLES[a]; out_items.append((a,'label',nm+':'))
                for i in range(n):
                    v=struct.unpack_from('<I',text,a-BASE+4*i)[0]
                    sym=funcs.get(v) or (f"str_{v:08x}" if v in addr2str else None)
                    out_items.append((a+4*i,'data',f"    .word {hex(v)}    # {sym if sym else ''}"+(f" \"{addr2str[v]}\"" if v in addr2str else '')))
                a+=4*n; continue
            if a in STRS:
                o=a-BASE; e=text.index(b'\0',o); s=text[o:e]
                escs=esc(s.decode('latin1'))
                out_items.append((a,'label',f"str_{a:08x}:")); out_items.append((a,'data',f'    .asciz "{escs}"')); a=BASE+e+1; continue
            # octets bruts jusqu'à prochaine chaîne/table/hi
            b=[]; s=a
            while a<hi and a not in STRS and a not in TABLES and len(b)<16: b.append(text[a-BASE]); a+=1
            asc=''.join(chr(c) if 32<=c<127 else '.' for c in b)
            out_items.append((s,'data',"    .byte "+", ".join(f"0x{c:02x}" for c in b)+f"    # {asc}"))
    for lo,hi in data_set:
        out_items.append((lo,'banner',f"# ---- donnees 0x{lo:08x}-0x{hi:08x}")); emit_data(lo,hi)
    out_items.sort(key=lambda t:(t[0],{'banner':0,'label':1,'ins':2,'word':2,'data':2}[t[1]]))
    return out_items,ins,funcs,targets,words

def render(items,header,demote=frozenset()):
    out=[header,"",".set noreorder",".set noat",".text",""]
    for it in items:
        k=it[1]
        if k=='ins':
            a,w,note,mark=it[0],it[3],it[4],it[5]
            body=it[2]
            if a in demote: body=f"    .word 0x{w:08x}   # {body.strip()}"
            tail=f"{a:08x}: {w:08x}"+(f"  {note}" if note else '')+(f"  {mark}" if mark else '')
            out.append(f"{body:<44} # {tail}")
        else: out.append(it[2])
    return "\n".join(out)+"\n"

import subprocess, tempfile, os
def gnu_build(src,workdir='/tmp/gnu'):
    os.makedirs(workdir,exist_ok=True)
    open(f'{workdir}/x.S','w').write(src)
    cmds=[['mipsel-linux-gnu-as','-EL','-march=r3000','-mips1','-mno-pdr','-o',f'{workdir}/x.o',f'{workdir}/x.S'],
          ['mipsel-linux-gnu-ld','-EL','-Ttext=0x80100000','-e','0','-o',f'{workdir}/x.elf',f'{workdir}/x.o'],
          ['mipsel-linux-gnu-objcopy','-O','binary','-j','.text',f'{workdir}/x.elf',f'{workdir}/x.bin']]
    for c in cmds:
        r=subprocess.run(c,capture_output=True,text=True)
        if r.returncode!=0: raise SystemExit(' '.join(c)+'\n'+r.stderr[:1500])
    return open(f'{workdir}/x.bin','rb').read()

def verify(items,text,header):
    demote=set()
    code_addrs={it[0] for it in items if it[1]=='ins'}
    for _ in range(8):
        src=render(items,header,frozenset(demote))
        enc=gnu_build(src)
        if len(enc)<len(text): enc=enc+b'\0'*(len(text)-len(enc))
        bad=[BASE+i for i in range(0,len(text),4) if enc[i:i+4]!=text[i:i+4]]
        if len(enc)!=len(text) and not bad: bad=['taille']
        if not bad: return src,demote
        if 'taille' in bad: raise SystemExit(f"taille differente {len(enc)} vs {len(text)}")
        new={a for a in bad if a in code_addrs}
        if not new or new<=demote: raise SystemExit("mismatch non resolu en "+", ".join(hex(a) for a in bad[:8]))
        demote|=new
    raise SystemExit("trop d'iterations")
