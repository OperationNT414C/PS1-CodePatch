import sys,struct; sys.path.insert(0,'/home/claude')
import sim
text=open(sys.argv[1] if len(sys.argv)>1 else '/home/claude/merge_text.bin','rb').read()
SAVE,LOAD=0x801019a8,0x80102018
EMPTY=(0xffffffff,0)
def code(tag,i): return (0x80000000|(0x10000*tag+2*i)&0x00ffffff|0x80000000, (tag*0x100+i)&0xffff)
def codes(tag,n): return [code(tag,i) for i in range(n)]
def run(fn,card,pads,table=None):
    s=sim.Sim(text,card=card,pads=pads,table=table); s.install_ui_hooks(); s.call(fn); return s
ok=True
def chk(c,m):
    global ok; print(("OK   " if c else "ECHEC"),m); ok&=bool(c)
def mkcard(sets):          # sets: {slot: [entries]}
    card={}
    for k,ents in sets.items():
        s=run(SAVE,card,[0x4000]*k+[0x20],ents); card=s.card
    return card
def tab(s): return s.get_table()
TRI,CIR,CRO,DOWN=0x10,0x20,0x40,0x4000

setA=codes(1,4)                       # ensemble de 4 codes dans l'emplacement 0
card=mkcard({0:setA})
# 1) cas de l'énoncé : 2 codes déjà saisis + ensemble de 4 -> 6 utilisés, les 4 nouveaux à la suite
have=codes(7,2)
s=run(LOAD,card,[TRI],have)
t=tab(s)
chk(t[:6]==have+setA and all(e==EMPTY for e in t[6:]),"2 codes existants + ensemble de 4 -> 6 codes, ordre conservé, reste vide")
# 2) 11 codes déjà saisis : seul le 1er code du set entre dans le dernier emplacement
have=codes(8,11)
s=run(LOAD,card,[TRI],have); t=tab(s)
chk(t[:11]==have and t[11]==setA[0] and all(e==EMPTY for e in t[12:]),"11 codes + set de 4 -> 12e emplacement = 1er code, les 3 autres ignorés")
# 3) tableau plein (12) : rien ne change
have=codes(9,12)
s=run(LOAD,card,[TRI],have); chk(tab(s)[:12]==have,"12 codes déjà saisis -> aucun changement")
# 4) tableau vide : équivaut à un chargement
s=run(LOAD,card,[TRI],[]); t=tab(s); chk(t[:4]==setA and all(e==EMPTY for e in t[4:]),"tableau vide + fusion = contenu du set")
# 5) trou dans le tableau : on remplit d'abord les espaces libres
have=[code(5,0),EMPTY,code(5,2)]
s=run(LOAD,card,[TRI],have); t=tab(s)
chk(t[0]==have[0] and t[1]==setA[0] and t[2]==have[2] and t[3]==setA[1] and t[4]==setA[2] and t[5]==setA[3],"trou au milieu : comblé d'abord, puis suite")
# 6) set avec trous (entrées vides ignorées)
setG=[code(3,0),EMPTY,code(3,2),EMPTY,code(3,4)]
cardG=mkcard({0:setG})
s=run(LOAD,cardG,[TRI],codes(7,1)); t=tab(s)
chk(t[:4]==[code(7,0),code(3,0),code(3,2),code(3,4)],"entrées vides du set sautées")
# 7) choix d'un autre ensemble dans la liste (2e) avec triangle
cardB=mkcard({0:setA,5:codes(2,3)})
s=run(LOAD,cardB,[DOWN,TRI],codes(7,1)); t=tab(s)
chk(t[:4]==[code(7,0)]+codes(2,3),"triangle sur le 2e élément de la liste (emplacement 5)")
# 8) non-régression : rond = remplacement complet
s=run(LOAD,cardB,[CIR],codes(7,5)); t=tab(s)
chk(t[:4]==setA and all(e==EMPTY for e in t[4:12]),"rond : remplace entièrement (comportement d'origine)")
# 9) croix : quitte sans rien changer
have=codes(6,3); s=run(LOAD,cardB,[CRO],have); chk(tab(s)[:3]==have and tab(s)[3]==EMPTY,"croix : sortie sans modification")
# 10) carte vide + triangle : pas de plantage, table inchangée, aucune écriture
have=codes(4,2); s=run(LOAD,{},[TRI],have); chk(tab(s)[:2]==have and not any(l[0]=='write' for l in s.log),"carte sans ensemble + triangle : rien ne change")
# 11) les entrées 13-16 du tableau ne sont pas touchées
have=codes(9,12); s=run(LOAD,card,[TRI],have+[]); chk(tab(s)[12:]==[EMPTY]*4,"entrées cachées 13-16 intactes")
# 12) message dans la barre + titre d'origine
s=run(LOAD,card,[CRO],codes(1,1)); sc=[(x[0],x[1],x[2]) for x in s.screen]
chk(any(x[2]=='CodeLoad' for x in sc),"le titre 'CodeLoad' est toujours affiché")
chk(any(x[2].startswith('O:Load') and x[0]==16 and x[1]==0x88 for x in sc),f"message affiché dans la barre {[x for x in sc if 'Merge' in x[2]][:1]}")
# 13) la sauvegarde / suppression marchent toujours (non-régression)
s=run(SAVE,{},[CIR],codes(1,12)); chk('TAYAN-CDAR10-SETS' in s.card,"sauvegarde toujours OK")
print("\nRESULTAT GLOBAL:","TOUT OK" if ok else "ECHECS")
